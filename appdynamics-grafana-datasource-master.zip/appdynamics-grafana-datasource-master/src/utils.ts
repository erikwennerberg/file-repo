import * as _ from 'lodash';


export function isAllValue(value) {
    return value === '$__all' || Array.isArray(value) && value[0] === '$__all';
}

export function getAllValue(variable) {
    if (variable.allValue) {
        return variable.allValue;
    }
    const values = [];
    for (let i = 1; i < variable.options.length; i++) {
        values.push(variable.options[i].value);
    }
    return values;
}


export function combineVariables(target, variables) {
    console.log('combineVariables', target, variables, variables.length);
    const arrays = [];
    variables.forEach((variable) => {
        console.log('variable', variable);
        let currentValue = variable.current.value;
        if (isAllValue(currentValue)) {
            currentValue = getAllValue(variable);
        }
        const name = variable.name;
        if (currentValue) {
            if (typeof currentValue === 'string') {
                if (target.application.indexOf(name) > -1 || target.metric.indexOf(name) > -1) {
                    arrays.push([{ [name]: currentValue }]);
                }
            } else {
                const values = [];
                console.log('currentValue', currentValue);
                currentValue.forEach((value) => {
                    if (target.application.indexOf(name) > -1 || target.metric.indexOf(name) > -1) {
                        values.push({ [name]: value });
                    }
                });
                if (values.length > 0) {
                    arrays.push(values);

                }
            }
        }

    });
    return cartesian(...arrays);
}

export function cartesian() {
    let r = [];
    let arg = arguments;
    let max = arg.length - 1;
    function helper(arr, i) {
        for (let j = 0, l = arg[i].length; j < l; j++) {
            let a = arr.slice(0);
            a.push(arg[i][j]);
            if (i === max) {
                r.push(a);
            } else {
                helper(a, i + 1);
            }
        }
    }

    helper([], 0);
    return r;
}

export function javaSplit(text, separator, n) {
    const split = text.split(separator);
    if (split.length <= n) {
        return split;
    }
    const out = split.slice(0, n - 1);
    out.push(split.slice(n - 1).join(separator));
    return out;
}

export function startsWith(target, value) {
    return target.indexOf(value) == 0;
}