# Grafana AppDynamics Datasource

This plugin is developed by the community and not officially supported by AppDynamics.

When configuring the datasource, use "proxy" and basic authentication.
Remember that the username should be "user@account", i.e: david.lopes@customer1

## Features

- Auto completion for Application and Metric names.
- Multiple applications on the same panel.
- Select multiple metrics with the wildcard character *.
- Powerful templating features, one dashboard, multiple apps, tiers, nodes, bts, etc!
- Select TopX Metrics (top 10 JVMs per Garbage Collection time, top 15 BTs per errors, etc)
- Compare different timeframes on the same panel! How are we today if compared to yesterday? Or last week?


## Templating examples

`Applications`  
Returns all Applications available in AppDynamics

`Ecommerce.Tiers`  
All tiers for the Ecommerce application

`Ecommerce.$Tier.Nodes`  
All nodes for the selected `Tier` template variable for the Ecommerce application

`ECommerce.Path.Service Endpoints|$Tier|`  
All Service Endpoints for the `Tier` template variable of the ECommerce application