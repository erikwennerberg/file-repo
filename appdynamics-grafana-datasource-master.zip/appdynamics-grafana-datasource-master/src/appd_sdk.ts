import * as dateMath from 'app/core/utils/datemath';
import * as appEvents from 'app/core/app_events';
import * as utils from './utils';
import * as _ from 'lodash';

/*
    This is the class where all AppD logic should reside.
    This gets Application Names, Metric Names and queries the API
*/

export class AppDynamicsSDK {
  url: string;

  constructor(instanceSettings, private backendSrv, private templateSrv) {
    this.url = instanceSettings.url;
  }

  targetContainsTemplate = function(target) {
    return (
      this.templateSrv.variableExists(target.metric) ||
      this.templateSrv.variableExists(target.application)
    );
  };

  setScopedVars(target, variables) {
    if (target.scopedVars) {
      for (const property in target.scopedVars) {
        if (target.scopedVars.hasOwnProperty(property)) {
          if (!utils.startsWith(property, '__')) {
            variables.forEach((variable) => {
              if (variable.name === property) {
                variable.current = target.scopedVars[property];
              }
            });
          }
        }
      }
    }
  }

  getEveryTarget(target) {
    const newTargets = [];
    let permutations = [];

    const variables = _.cloneDeep(this.templateSrv.variables);

    // console.log(variables);
    this.setScopedVars(target, variables);
    permutations = utils.combineVariables(target, variables);

    permutations.forEach((permutation) => {
      const newTarget = _.cloneDeep(target);

      permutation.forEach((variable) => {
        for (const property in variable) {
          if (variable.hasOwnProperty(property)) {
            const re = new RegExp('\\$' + property, 'g');
            newTarget.metric = newTarget.metric.replace(re, variable[property]);
            newTarget.application = newTarget.application.replace(
              re,
              variable[property]
            );
          }
        }
      });
      newTargets.push(newTarget);
    });
    return newTargets;
  }

  query(options) {
    const optionsStartTime = Math.ceil(dateMath.parse(options.range.from));
    const optionsEndTime = Math.ceil(dateMath.parse(options.range.to));
    const targets = _.cloneDeep(options.targets);
    // console.log(targets);

    const grafanaResponse = { data: [] };

    // For each one of the metrics the user entered:
    const requests = targets.map((target) => {
      target.scopedVars = options.scopedVars;
      let startTime = optionsStartTime;
      let endTime = optionsEndTime;

      if (target.timeOffsetValue && target.timeOffset) {
        startTime = startTime - Number(target.timeOffsetValue) * 60 * 60 * 1000;
        endTime = endTime - Number(target.timeOffsetValue) * 60 * 60 * 1000;
      }

      return new Promise((resolve) => {
        if (target.hide || _.isEmpty(target) || !target.metric) {
          // If the user clicked on the eye icon to hide, don't fetch the metrics.
          resolve();
        } else {
          // If the user is using templating, we have to treat them
          if (this.targetContainsTemplate(target)) {
            // Here we calculate all possible queries based on the templated values
            const allTargets = this.getEveryTarget(target);
            const everyRequest = allTargets.map((newTarget) => {
              return new Promise((innerResolve) => {
                this.getMetrics(
                  newTarget,
                  grafanaResponse,
                  startTime,
                  endTime,
                  options,
                  innerResolve
                );
              });
            });

            return Promise.all(everyRequest).then(() => {
              resolve();
            });
          } else {
            // If we are here, no templates have been set and we can just get the metrics directly
            return this.getMetrics(
              target,
              grafanaResponse,
              startTime,
              endTime,
              options,
              resolve
            );
          }
        }
      });
    });

    return Promise.all(requests).then(() => {
      return grafanaResponse;
    });
  }

  getMetrics(target, grafanaResponse, startTime, endTime, options, callback) {
    var rollUp = target.rollUp ? 'true' : 'false';
    // console.log('Target: ', rollUp);

    return this.backendSrv
      .datasourceRequest({
        url:
          this.url +
          '/controller/rest/applications/' +
          target.application +
          '/metric-data',
        method: 'GET',
        params: {
          'metric-path': target.metric,
          'time-range-type': 'BETWEEN_TIMES',
          'start-time': startTime,
          'end-time': endTime,
          rollup: rollUp,
          output: 'json'
        },
        headers: { 'Content-Type': 'application/json' }
      })
      .then((response) => {
        // A single metric can have multiple results if the user chose to use a wildcard
        // Iterates on every result.

        response.data.forEach((metricElement) => {
          const pathSplit = metricElement.metricPath.split('|');
          let legend = target.showAppOnLegend ? target.application + ' - ' : '';

          // Legend options
          switch (target.transformLegend) {
            case 'Segments': // TODO: Maybe a Regex option as well
              const segments = target.transformLegendText.split(',');
              for (let i = 0; i < segments.length; i++) {
                const segment = Number(segments[i]) - 1;
                if (segment < pathSplit.length) {
                  legend +=
                    pathSplit[segment] + (i === segments.length - 1 ? '' : '|');
                }
              }
              break;

            default:
              legend += metricElement.metricPath;
          }

          legend +=
            target.timeOffset && target.timeOffsetValue
              ? ' (offset ' + target.timeOffsetValue + 'h)'
              : '';
          grafanaResponse.data.push({
            target: target.alias ? target.alias : legend,
            datapoints: this.convertMetricData(metricElement, target)
          });
        });
      })
      .then(() => {
        // The user might only want a subset of data
        // Ie: the top 10 JVMs by memory instead of 150 different JVMs.
        if (target.topX && target.topXValue) {
          // console.log(grafanaResponse.data);
          grafanaResponse.data = this.getTopX(
            grafanaResponse.data,
            target.topXValue
          );
          // console.log(grafanaResponse);
        }
        console.log('Porra Igor', target);
        console.log(grafanaResponse);
        callback();
      })
      .catch((err) => {
        // If we are here, we were unable to get metrics

        let errMsg = 'Error getting metrics.';
        if (err.data) {
          if (err.data.indexOf('Invalid application name') > -1) {
            errMsg = `Invalid application name ${target.application}`;
          }
        }
        appEvents.emit('alert-error', ['Error', errMsg]);
        callback();
      });
  }

  // This helper method just converts the AppD response to the Grafana format
  convertMetricData(metricElement, target) {
    const responseArray = [];

    metricElement.metricValues.forEach((metricValue) => {
      let startTime = metricValue.startTimeInMillis;

      const aggregation = target.aggregation
        ? target.aggregation.toLowerCase()
        : 'value';
      // We want the offset but want to show it like if it
      if (target.timeOffsetValue && target.timeOffset) {
        startTime = startTime + Number(target.timeOffsetValue) * 60 * 60 * 1000;
      }
      responseArray.push([metricValue[aggregation], startTime]);
    });

    return responseArray;
  }

  sumDataPoints(data: Array<Array<number>>) {
    if (data.length === 0) {
      return 0;
    }
    return data.reduce((previous, current) => {
      return [previous[0] + current[0]];
    })[0];
  }

  getTopX(arrayOfMetrics: any[], topXValue: number) {
    return arrayOfMetrics
      .sort((a, b) => {
        const valueA = this.sumDataPoints(a.datapoints);
        const valueB = this.sumDataPoints(b.datapoints);
        return valueB - valueA;
      })
      .slice(0, topXValue);
  }

  testDatasource() {
    return this.backendSrv
      .datasourceRequest({
        url: this.url + '/controller/rest/applications', // TODO: Change this to a faster controller api call.
        method: 'GET',
        params: { output: 'json' }
      })
      .then((response) => {
        if (response.status === 200) {
          const numberOfApps = response.data.length;
          return {
            status: 'success',
            message: 'Data source is working, found ' + numberOfApps + ' apps',
            title: 'Success'
          };
        } else {
          return {
            status: 'failure',
            message: 'Data source is not working: ' + response.status,
            title: 'Failure'
          };
        }
      });
  }
  annotationQuery() {
    // TODO implement annotationQuery
  }

  getBusinessTransactionNames(appName, tierName) {
    const url =
      this.url +
      '/controller/rest/applications/' +
      appName +
      '/business-transactions';
    return this.backendSrv
      .datasourceRequest({
        url,
        method: 'GET',
        params: { output: 'json' }
      })
      .then((response) => {
        if (response.status === 200) {
          if (tierName) {
            return this.getBTsInTier(tierName, response.data);
          } else {
            return this.getFilteredNames('', response.data);
          }
        } else {
          return [];
        }
      })
      .catch((error) => {
        return [];
      });
  }

  getTierNames(appName) {
    return this.backendSrv
      .datasourceRequest({
        url: this.url + '/controller/rest/applications/' + appName + '/tiers',
        method: 'GET',
        params: { output: 'json' }
      })
      .then((response) => {
        if (response.status === 200) {
          return this.getFilteredNames('', response.data);
        } else {
          return [];
        }
      })
      .catch((error) => {
        return [];
      });
  }

  getNodeNames(appName, tierName) {
    let url = this.url + '/controller/rest/applications/' + appName + '/nodes';
    if (tierName) {
      url =
        this.url +
        '/controller/rest/applications/' +
        appName +
        '/tiers/' +
        tierName +
        '/nodes';
    }
    return this.backendSrv
      .datasourceRequest({
        url,
        method: 'GET',
        params: { output: 'json' }
      })
      .then((response) => {
        if (response.status === 200) {
          return this.getFilteredNames('', response.data);
        } else {
          return [];
        }
      })
      .catch((error) => {
        return [];
      });
  }

  getTemplateNames(query) {
    const possibleQueries = ['BusinessTransactions', 'Tiers', 'Nodes', 'Path'];

    const results = [];

    if (query.indexOf('.') > -1) {
      const values = utils.javaSplit(query, '.', 2);
      const appName = values[0];
      const metricName = values[1];
      let allQueries = [];

      const target = { application: appName, metric: metricName };
      if (this.targetContainsTemplate(target)) {
        // console.log(target);
        allQueries = this.getEveryTarget(target);
      } else {
        allQueries = [target];
      }

      allQueries.forEach((singleQuery) => {
        const app = singleQuery.application;
        const metric = singleQuery.metric.split('.');

        let type;
        let metricPath;
        let tierName;

        if (metric[0] === 'Path') {
          type = metric[0];
          metricPath = metric.slice(1).join('.');
        } else if (metric.length === 2) {
          tierName = metric[0];
          type = metric[1];
        } else {
          type = metric[0];
        }

        if (possibleQueries.indexOf(type) === -1) {
          appEvents.emit('alert-error', [
            'Error',
            'Templating must be one of Applications, AppName.BusinessTransactions, AppName.Tiers, AppName.Nodes, AppName.Path'
          ]);
        } else {
          switch (type) {
            case 'BusinessTransactions':
              metricPath =
                'Business Transaction Performance|Business Transactions|' +
                tierName +
                '|';
              results.push(this.getMetricNames(app, metricPath));
              break;
            case 'Tiers':
              metricPath = 'Application Infrastructure Performance|';
              results.push(this.getMetricNames(app, metricPath));
              break;
            case 'Nodes':
              metricPath =
                'Application Infrastructure Performance|' +
                tierName +
                '|Individual Nodes|';
              results.push(this.getMetricNames(app, metricPath));
              break;
            case 'Path':
              results.push(this.getMetricNames(app, metricPath));
              break;
            default:
              appEvents.emit('alert-error', [
                'Error',
                "The value after '.' must be BusinessTransactions, Tiers or Nodes"
              ]);
          }
        }
      });
    } else {
      results.push(this.getApplicationNames(''));
    }

    return Promise.all(results).then((arrays) => {
      return _.flatten(arrays);
    });
  }

  // Application Infrastructure Performance|Root|Individual Nodes
  getApplicationNames(query) {
    const extraApps = [{ name: 'Server & Infrastructure Monitoring' }];
    const templatedQuery = this.templateSrv.replace(query).replace(/\\/g, '');
    return this.backendSrv
      .datasourceRequest({
        url: this.url + '/controller/rest/applications',
        method: 'GET',
        params: { output: 'json' }
      })
      .then((response) => {
        if (response.status === 200) {
          response.data = response.data.concat(extraApps);
          return this.getFilteredNames(templatedQuery, response.data);
        } else {
          return [];
        }
      })
      .catch((error) => {
        return [];
      });
  }

  getMetricNames(app, query) {
    let templatedApp;
    let templatedQuery;
    const target = { application: app, metric: query || '' };

    if (this.targetContainsTemplate(target)) {
      const allQueries = this.getEveryTarget(target);

      templatedApp = allQueries[0].application;
      templatedQuery = allQueries[0].metric;
    } else {
      templatedApp = app;
      templatedQuery = query;
    }

    const params = { output: 'json' };
    if (query.indexOf('|') > -1) {
      params['metric-path'] = templatedQuery;
    }

    return this.backendSrv
      .datasourceRequest({
        url:
          this.url +
          '/controller/rest/applications/' +
          templatedApp +
          '/metrics',
        method: 'GET',
        params
      })
      .then((response) => {
        if (response.status === 200) {
          return this.getFilteredNames(templatedQuery, response.data);
        } else {
          return [];
        }
      })
      .catch((error) => {
        return [];
      });
  }

  getFilteredNames(query, arrayResponse) {
    if (query.indexOf('|') > -1) {
      const queryPieces = query.split('|');
      query = queryPieces[queryPieces.length - 1];
    }

    if (query.length === 0) {
      return arrayResponse;
    } else {
      // Only return the elements that match what the user typed, this is the essence of autocomplete.
      return arrayResponse.filter((element) => {
        return (
          query.toLowerCase().indexOf(element.name.toLowerCase()) !== -1 ||
          element.name.toLowerCase().indexOf(query.toLowerCase()) !== -1
        );
      });
    }
  }

  getBTsInTier(tierName, arrayResponse) {
    // We only want the BTs that belong to the tier
    return arrayResponse.filter((element) => {
      return element.tierName.toLowerCase() === tierName.toLowerCase();
    });
  }
}
